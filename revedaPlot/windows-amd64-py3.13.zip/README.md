# RevEDA Plot Plugin

## Overview
RevEDA Plot (revedaPlot) is an advanced waveform visualization and analysis plugin for
Revolution EDA that provides interactive plotting capabilities for circuit simulation
results. It features a modern PyQtGraph-based interface with support for multi-dimensional
data visualization, parameter sweep plotting, real-time measurement tools, and high-quality
plot export functionality, seamlessly integrating with the revedasim plugin for
comprehensive simulation workflow.

If you encounter any issues or have suggestions for improvement, please feel free to reach out 
using the Revolution EDA support channels.

## Features

### Visualization Capabilities

- **Interactive Waveform Plotting**: Real-time zoom, pan, and measurement on simulation
  waveforms
- **Multi-Plot Support**: Combined and separate plot views for different signal types
- **Parameter Sweep Visualization**: Automatic plotting of parametric simulation results
  with clear parameter identification
- **Data Frame Integration**: Native support for Polars DataFrame structures for efficient
  data handling
- **Dynamic Plot Updates**: Live plot updates during simulation execution

### User Interface

- **Tabbed Interface**: Multiple plot tabs for organizing different analyses and results
- **Customizable Layouts**: Flexible plot arrangement with resizable panels
- **Interactive Legends**: Clickable legends for signal visibility control
- **Context Menus**: Right-click access to plot operations and settings
- **Measurement Tools**: Built-in cursors and measurement capabilities

### Plot Types and Formats

- **Time-Domain Plots**: Transient analysis results with time-based x-axis
- **Frequency-Domain Plots**: AC analysis with logarithmic and linear frequency scales
- **Parametric Plots**: DC sweep and parameter variation visualization
- **Combined Plots**: Multiple signals on single plot with automatic color cycling
- **Separate Plots**: Individual plots for each parameter combination

### Measurement and Analysis

- **Interactive Cursors**: Vertical line cursors with automatic value interpolation
- **Zoom Controls**: X-axis and Y-axis specific zoom operations
- **Auto-scaling**: Automatic plot range adjustment for optimal viewing
- **Grid Controls**: Configurable grid display and styling
- **Color Management**: Automatic color cycling with customizable palettes

### Export and Documentation

- **High-Quality Export**: PNG, PDF, and SVG export with publication-ready formatting
- **Print Support**: Direct printing with optimized layouts
- **Plot Annotations**: Title and axis labeling with parameter information
- **Timestamp Integration**: Automatic timestamping of plot sessions
- **Background Options**: Light and dark theme support for different use cases

### Data Processing

- **Signal Processing**: Built-in signal processing and mathematical operations
- **Data Filtering**: Filtering capabilities for large datasets
- **Expression Evaluation**: Support for mathematical expressions on plotted data
- **Unit Handling**: Automatic unit conversion and display formatting
- **Memory Optimization**: Efficient handling of large simulation datasets

## Integration Features

### Plugin Architecture

- **Seamless Integration**: Direct integration with Revolution EDA's plugin system
- **revedasim Compatibility**: Automatic data reception from simulation plugin
- **Modular Design**: Independent operation while maintaining tight integration
- **Event-Driven Updates**: Real-time plot updates as simulation data becomes available

### Data Interface

- **Multiple Data Sources**: Support for various simulation output formats
- **Raw File Processing**: Direct reading of Xyce raw files and other simulator outputs
- **Data Validation**: Automatic data integrity checking and error handling
- **Format Conversion**: Transparent conversion between different data formats

## Supported Plot Types

### Waveform Plots

- **Voltage vs Time**: Standard transient analysis visualization
- **Current vs Time**: Current waveform plotting with proper scaling
- **Voltage vs Frequency**: AC analysis magnitude and phase plots
- **Parametric Sweeps**: Multi-dimensional parameter variation plots

### Analysis-Specific Plots

- **DC Sweep Plots**: Voltage/current vs swept parameter
- **AC Response**: Magnitude and phase frequency response
- **Noise Plots**: Noise spectral density visualization
- **Harmonic Balance**: Steady-state harmonic analysis results

## User Interface Elements

### Main Window

- **Plot Canvas**: Primary plotting area with interactive controls
- **Tool Bars**: Quick access to common plotting operations
- **Status Bar**: Real-time information about plot state and measurements
- **Menu System**: Comprehensive menu structure for all features

### Interactive Controls

- **Mouse Operations**: Zoom, pan, and measurement with mouse interactions
- **Keyboard Shortcuts**: Efficient navigation and operation via keyboard
- **Touch Support**: Basic touch interface support for tablet devices
- **Accessibility**: Screen reader and keyboard navigation support

## Installation and Usage

The revedaPlot plugin is automatically loaded when Revolution EDA starts. Access plotting
features through:

1. **Automatic Launch**: Plots appear automatically when simulation completes
2. **Manual Launch**: Direct access through Revolution EDA menus
3. **Data Import**: Import external data files for visualization
4. **Export Functions**: Save plots in various formats for documentation

## Requirements

- Revolution EDA core application
- PyQtGraph library for high-performance plotting
- Qt6/PySide6 for user interface components
- Python packages: polars, numpy, pyqtgraph
- Optional: matplotlib for additional export formats

## Configuration

Plot settings can be customized through:

- User preferences for default plot appearance
- Per-plot configuration for specific visualization needs
- Color scheme selection for different use cases
- Export quality and format settings